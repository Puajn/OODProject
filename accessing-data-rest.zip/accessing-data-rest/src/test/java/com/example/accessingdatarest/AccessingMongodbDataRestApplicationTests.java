package com.example.accessingdatarest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingMongodbDataRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
